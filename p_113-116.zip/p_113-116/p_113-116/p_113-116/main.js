mustache_X = 0;
mustache_Y = 0;

function preload(){
    picture = loadImage("https://i.postimg.cc/3x3QzSGq/m.png");
    }

    function setup(){
        canvas = createCanvas(400,400);
        canvas.center();
        camera = createCapture(VIDEO);
        camera.size(400,400);
        camera.hide();
    
        posenet = ml5.poseNet(camera,modelLoaded);
        posenet.on('pose',gotPoses);
    }

function modelLoaded(){
    console.log("PoseNet has started");
}

function gotPoses(results){
    if(results.length > 0){
        console.log(results);
    
        mustache_X = results[0].pose.nose.x-28;
        mustache_Y = results[0].pose.nose.y-0;
    
        console.log("Mustache X = " + mustache_X);
        console.log("Mustache Y = " + mustache_Y);
    }
    }

    function draw(){
        image(camera,0,0,400,400);
        
        image(picture,mustache_X,mustache_Y,60,60);
    }


function capture(){
    save("mushtache.png");
}

